package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{
	@RequestMapping("/hash")
	public String myHash() {
		// Create MessageDigest object
		MessageDigest messageDigest = null;
		// String to encrypt
		String data = "Jordan Ballard Checksum";
		// String to hold encrypted text
		String checksumVal;
		
		try {
			// Initialize MessageDigest object with SHA-256 hash algorithm
			messageDigest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			System.err.println("No such algorithm.");
		}
		
		// Pass data to MessageDigest object
		messageDigest.update(data.getBytes());
		// Generate the message digest
		byte[] digest = messageDigest.digest();
		// Convert the hash value to hex
		checksumVal = bytesToHex(digest);
		
		return "<p>Data: " + data + "<p>" + "<p>Name of Cipher Algorithm Used: SHA-256</p>" + "<p>Checksum Value: " + checksumVal + "</p>";
	}
	
	private String bytesToHex(byte[] bytes) {
		StringBuilder sb = new StringBuilder();
		
		// For each element in byte array
		for (int i = 0; i < bytes.length; i++) {
			// Get output of bitwise AND as unsigned integer in base 16
			String hex = Integer.toHexString(0xff & bytes[i]);
			if (hex.length() == 1) {
				// Keep leading zero
				sb.append('0');
			}
			// Build hex string
			sb.append(hex);	
		}
		// Return completed hex string
		return sb.toString();
	}
}